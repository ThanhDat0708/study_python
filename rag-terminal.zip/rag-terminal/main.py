"""Hệ thống RAG cơ bản với ChromaDB và OpenAI API."""
# 1. Load tài liệu 'data-sample.txt'
# 2. Chunking tài liệu thành các đoạn nhỏ
# 3. Tạo embedding cho từng đoạn bằng openai_service.get_embedding
# 4. Thêm embedding vào ChromaDB
# 5. Nhận câu hỏi của người dùng, tìm kiếm 5 vector gần nhất trong ChromaDB
# 6. Gửi câu hỏi và các đoạn tìm được đến OpenAI Responses API để nhận câu trả lời
# 7. Trả về câu trả lời cho người dùng và lặp lại bước 5-7 cho các câu hỏi tiếp theo. Kết thúc khi người dùng nhập văn bản rỗng

from loader import txt_loader
from chunker import chunk_by_token
from chromadb_service import add_documents, search
from openai_service import get_response, chat_history


# 1. Load tài liệu
print("Đang load tài liệu...")
content = txt_loader("data-sample.txt")

# 2. Chunking
print("Đang chunking...")
chunks = chunk_by_token(content)

# 3-4. Tạo embedding và thêm vào ChromaDB
print("Đang tạo embedding và lưu vào ChromaDB...")
ids = [f"chunk_{i}" for i in range(len(chunks))]
add_documents(ids=ids, texts=chunks)
print(f"Đã lưu {len(chunks)} chunks vào ChromaDB.")

# 5-7. Vòng lặp hỏi đáp
print("\n--- HỎI ĐÁP ---")
while True:
    question = input("\nBạn hỏi: ").strip()
    if not question:
        print("Kết thúc.")
        break

    # Tìm kiếm 5 đoạn gần nhất
    results = search(question, n_results=5)
    contexts = results["documents"][0]

    # Tạo prompt RAG
    rag_message = (
        "Dựa vào các thông tin sau đây:\n"
        + "\n---\n".join(contexts)
        + f"\n\nTrả lời câu hỏi: {question}"
    )

    # Gửi đến OpenAI và in kết quả
    answer = get_response(rag_message)
    print(f"ABC Assistant: {answer}")