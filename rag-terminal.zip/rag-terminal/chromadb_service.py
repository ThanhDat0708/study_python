# Thao tác với ChromaDB
# Tạo database, collection, thêm embedding, tìm kiếm embedding

"""Module thao tác với ChromaDB in-memory."""

import chromadb
from openai_service import get_embedding


# Khởi tạo ChromaDB in-memory
db = chromadb.Client()

# Tạo hoặc lấy collection
collection = db.get_or_create_collection(name="tai_lieu")


def add_documents(ids: list[str], texts: list[str], metadatas: list[dict] | None = None):
    """Thêm tài liệu kèm embedding vào collection."""
    embeddings = get_embedding(texts)
    collection.add(
        ids=ids,
        embeddings=embeddings,
        documents=texts,
        metadatas=metadatas,
    )


def search(query: str, n_results: int = 5):
    """Tìm kiếm tài liệu gần nhất với câu truy vấn."""
    query_vector = get_embedding([query])[0]
    return collection.query(
        query_embeddings=[query_vector],
        n_results=n_results,
    )
