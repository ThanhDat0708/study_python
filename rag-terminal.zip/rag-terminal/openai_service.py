"""Module tương tác với OpenAI API: embedding và chat."""

from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

client = OpenAI()

# System prompt ngắn cho chat
SYSTEM_PROMPT = """
Bạn là trợ lý AI hữu ích, trả lời ngắn gọn và chính xác
theo ngữ cảnh của câu hỏi.
Không trả lời ngoài phạm vi kiến thức liên quan.
Nếu không biết, hãy trả lời "Câu hỏi không thuộc phạm vi kiến thức của tôi.".
"""

# Lịch sử hội thoại
chat_history = []


def get_embedding(texts: list[str]) -> list[list[float]]:
    """Tạo embedding cho văn bản bằng text-embedding-3-small."""
    response = client.embeddings.create(
        input=texts,
        model="text-embedding-3-small",
    )
    return [item.embedding for item in response.data]


def get_response(user_message: str) -> str:
    """Gửi tin nhắn đến OpenAI Responses API và trả về phản hồi."""
    chat_history.append({"role": "user", "content": user_message})

    try:
        response = client.responses.create(
            model="gpt-5.4-mini",
            instructions=SYSTEM_PROMPT,
            input=chat_history,
        )
        reply = response.output_text
        chat_history.append({"role": "assistant", "content": reply})
        return reply
    except Exception as ex:
        return f"Lỗi: {ex}"

