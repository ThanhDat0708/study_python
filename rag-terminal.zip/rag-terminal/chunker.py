import tiktoken

def chunk_by_token(text, chunk_size=400, overlap=50) -> list[str]:
    """
    Chia văn bản thành các chunk dựa trên số lượng token.
    Dùng tiktoken để mã hóa và chia nhỏ với overlap.
    """
    enc = tiktoken.get_encoding("cl100k_base")
    tokens = enc.encode(text)

    chunks = []
    start = 0
    while start < len(tokens):
        end = start + chunk_size
        chunk_tokens = tokens[start:end]
        chunks.append(enc.decode(chunk_tokens))
        start += chunk_size - overlap

    return chunks
